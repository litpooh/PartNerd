package hk.hkucs.partnerd;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class displayCourses extends AppCompatActivity  implements View.OnClickListener{
    String user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_courses);

        Intent intent = this.getIntent();
        user_id = intent.getStringExtra("user_id");
        ArrayList<String> courseCodes = intent.getStringArrayListExtra("courseCodes");
        ArrayList<String> courseNames = intent.getStringArrayListExtra("courseNames");
        ArrayList<String> courseIds = intent.getStringArrayListExtra("courseIds");


        Display display = getWindowManager().getDefaultDisplay();
        double width = display.getWidth()/1.5;
        double ratio = ((float) (width))/300.0;
        int height = (int)(ratio*50);

        LinearLayout dynamicView = (LinearLayout) findViewById(R.id.courses);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) width, height);
        params.topMargin=10;
        params.gravity = Gravity.CENTER;

        Log.d("array size", "length: " + courseCodes.size());

        for(int i = 0; i < courseCodes.size(); i++){
            Button btn = new Button(this);
            btn.setId(i+1);
            btn.setText(courseCodes.get(i));
            btn.setLayoutParams(params);
            btn.setBackgroundColor(Color.parseColor("#0ED689"));
            btn.setTextColor(Color.parseColor("#ffffff"));
            dynamicView.addView(btn);
            final int index = i;
            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Log.d(courseCodes.get(index), courseNames.get(index));
                    Intent intent = new Intent(getBaseContext(), EnrollOrBrowse.class);
                    intent.putExtra("user_id",user_id);
                    intent.putExtra("courseId",courseIds.get(index));
                    intent.putExtra("courseCode",courseCodes.get(index));
                    intent.putExtra("courseName",courseNames.get(index));
//                    Log.i(courseIds.get(index), courseNames.get(index));
                    startActivity(intent);
                }
            });
        }
        dynamicView.setOrientation(LinearLayout.VERTICAL);
    }


    @Override
    public void onClick(View v) {


    }

}