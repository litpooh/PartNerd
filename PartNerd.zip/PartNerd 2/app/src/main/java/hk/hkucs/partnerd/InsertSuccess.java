package hk.hkucs.partnerd;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InsertSuccess extends AppCompatActivity {
    String user_id;
    String courseName;
    String courseId;
    String courseCode;
    // need to retrieve from JSON
    String user_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_success);

        Intent intent = this.getIntent();
        user_id = intent.getStringExtra("user_id");
        courseId = intent.getStringExtra("courseId");
        courseCode = intent.getStringExtra("courseCode");
        courseName = intent.getStringExtra("courseName");

        Button btn_courses = (Button) findViewById(R.id.backcourses);
        btn_courses.setOnClickListener(this::onClick);

        connect(user_id, courseId);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            //case R.id.seeotherusers:
            //    Intent intent = new Intent(getBaseContext(), ListCourseUsers.class);
            //    intent.putExtra("user_id", user_id);
            //    intent.putExtra("courseId", courseId);
            //    intent.putExtra("courseCode", courseCode);
            //    intent.putExtra("courseName", courseName);
            //    startActivity(intent);

            case R.id.backcourses:
                Toast.makeText(this, "Back", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), Courses.class);
                intent2.putExtra("user_id",user_id);
                startActivity(intent2);
        }
    }


    public String ReadBufferedHTML(BufferedReader reader, char [] htmlBuffer, int bufSz) throws java.io.IOException {
        htmlBuffer[0] = '\0';
        int offset = 0;
        do {
            int cnt = reader.read(htmlBuffer, offset, bufSz - offset);
            if (cnt > 0) {
                offset += cnt;
            } else {
                break;
            }
        } while (true);
        return new String(htmlBuffer);
    }
    public String getJsonPage(String url) {
        HttpURLConnection conn_object = null;
        final int HTML_BUFFER_SIZE = 2*1024*1024;
        char htmlBuffer[] = new char[HTML_BUFFER_SIZE];
        try {
            URL url_object = new URL(url);
            conn_object = (HttpURLConnection) url_object.openConnection();
            conn_object.setInstanceFollowRedirects(true);
            BufferedReader reader_list = new BufferedReader
                    (new InputStreamReader(conn_object.getInputStream()));
            String HTMLSource = ReadBufferedHTML(reader_list, htmlBuffer,
                    HTML_BUFFER_SIZE);
            reader_list.close();
            return HTMLSource;
        } catch (Exception e) {
            Log.e("MYAPP", "exception", e);
            return "Fail to login";
        } finally {
// When HttpClient instance is no longer needed,
// shut down the connection manager to ensure
// immediate deallocation of all system resources
            if (conn_object != null) {
                conn_object.disconnect();
            }
        }
    }
    protected void alert(String title, String mymessage){
        new AlertDialog.Builder(this)
                .setMessage(mymessage)
                .setTitle(title)
                .setCancelable(true)
                .setNegativeButton(android.R.string.cancel,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton){}
                        }
                )
                .show();}
    public void parse_JSON_String_and_Switch_Activity(String JSONString) {
        try {
            JSONObject rootJSONObj = new JSONObject(JSONString);
            user_id = rootJSONObj.getString("user_id");
            user_name = rootJSONObj.getString("user_name");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        TextView textView0 = (TextView) findViewById(R.id.insertsuccess);
        textView0.setText("Insert Successfully!");
        TextView textView1 = (TextView) findViewById(R.id.user_id);
        textView1.setText("User id: "+user_id);
        TextView textView2 = (TextView) findViewById(R.id.user_name);
        textView2.setText("User name: "+user_name);
        TextView textView3 = (TextView) findViewById(R.id.course);
        textView3.setText(courseCode + " "+ courseName);

    }
    public void connect(final String user_id, final String courseId){
        final ProgressDialog pdialog = new ProgressDialog(this);
        pdialog.setCancelable(false);
        pdialog.setMessage("Connecting ...");
        pdialog.show();
        final String url = "https://i.cs.hku.hk/~knchu/InsertSuccess.php"
                + (user_id.isEmpty() ? "" : "?action=insert&user_id="
                + android.net.Uri.encode(user_id, "UTF-8"))
                + (courseId.isEmpty() ? "" : "&course_id="
                + android.net.Uri.encode(courseId, "UTF-8"));
        ExecutorService executor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(new Runnable() {
            @Override
            public void run() {
                boolean success = true;
                pdialog.setMessage("Before ...");
                pdialog.show();
                final String jsonString = getJsonPage(url);
                if (jsonString.equals("Fail to insert"))
                    success = false;
                final boolean finalSuccess = success;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (finalSuccess) {
                            parse_JSON_String_and_Switch_Activity(jsonString);
                        } else {
                            alert( "Error", "Fail to connect" );
                        }
                        pdialog.hide();
                    }
                });
            }
        });
    }
}