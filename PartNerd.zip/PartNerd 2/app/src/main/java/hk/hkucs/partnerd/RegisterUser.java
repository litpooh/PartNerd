package hk.hkucs.partnerd;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener {
    TextView banner;
    EditText txt_name;
    EditText txt_phoneNumber;
    EditText txt_email;
    EditText txt_password;
    EditText txt_nationality;
    EditText txt_language;
    EditText txt_gpa;

    Button registerUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        banner = (TextView) findViewById(R.id.banner);
        txt_name = (EditText)findViewById(R.id.name);
        txt_phoneNumber = (EditText)findViewById(R.id.phone_number);
        txt_email = (EditText)findViewById(R.id.email);
        txt_password = (EditText)findViewById(R.id.password);
        txt_nationality = (EditText)findViewById(R.id.nationality);
        txt_language = (EditText)findViewById(R.id.language);
        txt_gpa = (EditText)findViewById(R.id.gpa);
        registerUser = (Button)findViewById(R.id.registerUser);
        registerUser.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerUser:
                registerUser();
                return;
        }
    }

    private void registerUser() {
        String name = txt_name.getText().toString();
        String phoneNumber = txt_phoneNumber.getText().toString().trim();
        String email = txt_email.getText().toString().trim();
        String password = txt_password.getText().toString().trim();
        String nationality = txt_nationality.getText().toString().trim();
        String language = txt_language.getText().toString().trim();
        String gpa = txt_gpa.getText().toString().trim();

        if (name.isEmpty()){
            Toast.makeText(this, "You did not enter name", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phoneNumber.isEmpty()){
            Toast.makeText(this, "You did not enter phone number", Toast.LENGTH_SHORT).show();
            return;
        }
        if (email.isEmpty()){
            Toast.makeText(this, "You did not enter email", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.isEmpty()){
            Toast.makeText(this, "You did not enter password", Toast.LENGTH_SHORT).show();
            return;
        }
        if (nationality.isEmpty()){
            Toast.makeText(this, "You did not enter nationality", Toast.LENGTH_SHORT).show();
            return;
        }
        if (language.isEmpty()){
            Toast.makeText(this, "You did not enter language", Toast.LENGTH_SHORT).show();
            return;
        }
        if (gpa.isEmpty()){
            Toast.makeText(this, "You did not enter gpa", Toast.LENGTH_SHORT).show();
            return;
        }

        connect(name, phoneNumber, email, password, nationality, language, gpa);
    }
    public String ReadBufferedHTML(BufferedReader reader,
                                   char [] htmlBuffer, int bufSz) throws java.io.IOException {
        htmlBuffer[0] = '\0';
        int offset = 0;
        do {
            int cnt = reader.read(htmlBuffer, offset, bufSz - offset);
            if (cnt > 0) {
                offset += cnt;
            } else {
                break;
            }
        } while (true);
        return new String(htmlBuffer);
    }
    public String getJsonPage(String url) {
        HttpURLConnection conn_object = null;
        final int HTML_BUFFER_SIZE = 2*1024*1024;
        char htmlBuffer[] = new char[HTML_BUFFER_SIZE];
        try {
            URL url_object = new URL(url);
            conn_object = (HttpURLConnection) url_object.openConnection();
            conn_object.setInstanceFollowRedirects(true);
            BufferedReader reader_list = new BufferedReader
                    (new InputStreamReader(conn_object.getInputStream()));
            String HTMLSource = ReadBufferedHTML(reader_list, htmlBuffer,
                    HTML_BUFFER_SIZE);
            reader_list.close();
            return HTMLSource;
        } catch (Exception e) {
            return "Fail to login";
        } finally {
// When HttpClient instance is no longer needed,
// shut down the connection manager to ensure
// immediate deallocation of all system resources
            if (conn_object != null) {
                conn_object.disconnect();
            }
        }
    }
    protected void alert(String title, String mymessage){
        new AlertDialog.Builder(this)
                .setMessage(mymessage)
                .setTitle(title)
                .setCancelable(true)
                .setNegativeButton(android.R.string.cancel,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton){}
                        }
                )
                .show();}
//    public void parse_JSON_String_and_Switch_Activity(String JSONString) {
//        ArrayList<String> role = new ArrayList<String>();
//        ArrayList<String> name = new ArrayList<String>();
//        try {
//            JSONObject rootJSONObj = new JSONObject(JSONString);
//            String instructor = rootJSONObj.getString("teacher_1");
//            role.add("Instructor");
//            name.add(instructor);
//            String teaching_assistant1 = rootJSONObj.getString("teacher_2");
//            role.add("Teaching Assistant");
//            name.add(teaching_assistant1);
//            String teaching_assistant2 = rootJSONObj.getString("teacher_3");
//            role.add("Teaching Assistant");
//            name.add(teaching_assistant2);
//            JSONArray jsonArray = rootJSONObj.optJSONArray("students");
//            for (int i=0; i<jsonArray.length(); ++i) {
//                String studentName = jsonArray.getString(i);
//                role.add("Student " + (i+1));
//                name.add(studentName);
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//    }
    public void connect(final String name,final String phoneNumber, final String email,final String password,final String nationality,final String language,final String gpa){
        final ProgressDialog pdialog = new ProgressDialog(this);
        pdialog.setCancelable(false);
        pdialog.setMessage("Connecting ...");
        pdialog.show();
        final String url = "https://i.cs.hku.hk/~knchu/registerUser.php"
                + (name.isEmpty() ? "" : "?action=insert&name="
                + android.net.Uri.encode(name, "UTF-8"))
                + (phoneNumber.isEmpty() ? "" : "&phone_number="
                + android.net.Uri.encode(phoneNumber, "UTF-8"))
                + (email.isEmpty() ? "" : "&email="
                + android.net.Uri.encode(email, "UTF-8"))
                + (password.isEmpty() ? "" : "&password="
                + android.net.Uri.encode(password, "UTF-8"))
                + (nationality.isEmpty() ? "" : "&nationality="
                + android.net.Uri.encode(nationality, "UTF-8"))
                + (language.isEmpty() ? "" : "&language="
                + android.net.Uri.encode(language, "UTF-8"))
                + (gpa.isEmpty() ? "" : "&gpa="
                + android.net.Uri.encode(gpa, "UTF-8"));
        ExecutorService executor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(new Runnable() {
            @Override
            public void run() {
                boolean success = true;
                pdialog.setMessage("Before ...");
                pdialog.show();
                final String jsonString = getJsonPage(url);
                if (jsonString.equals("Fail to login"))
                    success = false;
                final boolean finalSuccess = success;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (finalSuccess) {
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                            startActivity(intent);
                        } else {
                            alert( "Error", "Fail to connect" );
                        }
                        pdialog.hide();
                    }
                });
            }
        });
    }
}