package hk.hkucs.partnerd;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Request extends AppCompatActivity implements View.OnClickListener{
    String user_id;
    String otherUserId;
    String otherUserName;
    String otherUserNationality;
    String otherUserLanguage;
    String course_id;
    String gpa;
    String courseName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);

        Intent intent = this.getIntent();
        user_id = intent.getStringExtra("user_id");
        otherUserId = intent.getStringExtra("otherUserId");
        otherUserName = intent.getStringExtra("otherUserName");
        otherUserNationality = intent.getStringExtra("otherUserNationality");
        otherUserLanguage = intent.getStringExtra("otherUserLanguage");
        course_id = intent.getStringExtra("course_id");
        gpa = intent.getStringExtra("gpa");
        courseName = intent.getStringExtra("courseName");

//        Log.d("Other user name", otherUserName);

        TextView txt_otherUserName = (TextView) findViewById(R.id.otherUserName);
        txt_otherUserName.setText("Name: "+otherUserName);

        TextView txt_otherUserNationality = (TextView) findViewById(R.id.nationality);
        txt_otherUserNationality.setText("Nationality: "+otherUserNationality);

        TextView txt_otherUserLanguage = (TextView) findViewById(R.id.language);
        txt_otherUserLanguage.setText("Language: "+otherUserLanguage);

        TextView txt_gpa = (TextView) findViewById(R.id.gpa);
        txt_gpa.setText("GPA: "+gpa);

        Button btn_request = (Button) findViewById(R.id.request);
        btn_request.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.request){
            Toast.makeText(this, "request", Toast.LENGTH_SHORT).show();
            connect(user_id, otherUserId, course_id);
        }

    }

    public String ReadBufferedHTML(BufferedReader reader, char [] htmlBuffer, int bufSz) throws java.io.IOException {
        htmlBuffer[0] = '\0';
        int offset = 0;
        do {
            int cnt = reader.read(htmlBuffer, offset, bufSz - offset);
            if (cnt > 0) {
                offset += cnt;
            } else {
                break;
            }
        } while (true);
        return new String(htmlBuffer);
    }
    public String getJsonPage(String url) {
        HttpURLConnection conn_object = null;
        final int HTML_BUFFER_SIZE = 2*1024*1024;
        char htmlBuffer[] = new char[HTML_BUFFER_SIZE];
        try {
            URL url_object = new URL(url);
            conn_object = (HttpURLConnection) url_object.openConnection();
            conn_object.setInstanceFollowRedirects(true);
            BufferedReader reader_list = new BufferedReader
                    (new InputStreamReader(conn_object.getInputStream()));
            String HTMLSource = ReadBufferedHTML(reader_list, htmlBuffer,
                    HTML_BUFFER_SIZE);
            reader_list.close();
            return HTMLSource;
        } catch (Exception e) {
            Log.e("MYAPP", "exception", e);
            return "Fail to login";
        } finally {
// When HttpClient instance is no longer needed,
// shut down the connection manager to ensure
// immediate deallocation of all system resources
            if (conn_object != null) {
                conn_object.disconnect();
            }
        }
    }
    protected void alert(String title, String mymessage){
        new AlertDialog.Builder(this)
                .setMessage(mymessage)
                .setTitle(title)
                .setCancelable(true)
                .setNegativeButton(android.R.string.cancel,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton){}
                        }
                )
                .show();}
    public void parse_JSON_String_and_Switch_Activity(String JSONString) {
        ArrayList<String> userIds = new ArrayList<String>();
        ArrayList<String> userNames = new ArrayList<String>();
        try {
            JSONObject rootJSONObj = new JSONObject(JSONString);
            JSONArray userIdArray = rootJSONObj.optJSONArray("user_id");
            JSONArray userNameArray = rootJSONObj.optJSONArray("user_name");
            for (int i=0; i<userIdArray.length(); ++i) {
                String local_user_id = userIdArray.getString(i);
                String local_user_name = userNameArray.getString(i);
//                Log.i(local_user_id, local_user_name);
                userIds.add(local_user_id);
                userNames.add(local_user_name);
                Log.d(userIds.get(i), userNames.get(i));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public void connect(final String from, final String to, final String course_id){
        final ProgressDialog pdialog = new ProgressDialog(this);
        pdialog.setCancelable(false);
        pdialog.setMessage("Connecting ...");
        pdialog.show();
        final String url = "https://i.cs.hku.hk/~knchu/sendRequest.php"
                + (from.isEmpty() ? "" : "?action=insert&from="
                + android.net.Uri.encode(from, "UTF-8"))
                + (to.isEmpty() ? "" : "&to="
                + android.net.Uri.encode(to, "UTF-8"))
                + (course_id.isEmpty() ? "" : "&course_id="
                + android.net.Uri.encode(course_id, "UTF-8"));
        ExecutorService executor = Executors.newSingleThreadExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        executor.execute(new Runnable() {
            @Override
            public void run() {
                boolean success = true;
                pdialog.setMessage("Before ...");
                pdialog.show();
                final String jsonString = getJsonPage(url);
                if (jsonString.equals("Fail to get other users"))
                    success = false;
                final boolean finalSuccess = success;
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (finalSuccess) {
                            Intent intent = new Intent(getBaseContext(), RequestSuccess.class);
                            intent.putExtra("user_id", user_id);
                            intent.putExtra("otherUserId", otherUserId);
                            intent.putExtra("courseName", courseName);
                            startActivity(intent);
                        } else {
                            alert( "Error", "Fail to connect" );
                        }
                        pdialog.hide();
                    }
                });
            }
        });
    }
}